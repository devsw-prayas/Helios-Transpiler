using System.Windows;

namespace Helios_Transpiler
{
    public partial class App : Application { }
}
